from django.contrib import admin
from .models import student, book

admin.site.register(student)
admin.site.register(book)