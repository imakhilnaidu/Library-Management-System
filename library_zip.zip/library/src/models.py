from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class student(models.Model):
    Name = models.CharField(max_length=100)
    RegistrationId = models.CharField(max_length=50)
    Email = models.EmailField(max_length=100)
    College = models.CharField(max_length=50)
    Branch = models.CharField(max_length=100)
    MobileNumber = models.CharField(max_length=10)
    objects = models.Manager()

    def __str__(self):
        return self.RegistrationId

class book(models.Model):
    BookName = models.CharField(max_length=100)
    BookId = models.CharField(max_length=10)
    BookAuthor = models.CharField(max_length=100)

    def __str__(self):
        return self.BookName