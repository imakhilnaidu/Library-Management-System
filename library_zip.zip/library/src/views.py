from django.shortcuts import redirect, render
from .models import student, book
from django.contrib import messages
from django.db.models import Q

dict = {}

def index(request):
    if request.method == "POST":
        regid = request.POST.get("regid")
        
        if regid:
            data = student.objects.filter(Q(RegistrationId__icontains=regid))
            if data:
                dict["d"] = data
                return redirect("home")
            else:
                messages.info(request, "No Student Found")
        
    return render(request, "index.html")

def home(request):
    books = book.objects.all()
    return render(request, "home.html", {"books": books, "student": dict.get("d")})